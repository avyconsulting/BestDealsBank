package com.hsbc.bestdealsbank.domain;

public enum CalculatorType {

    simple, compound;

}
